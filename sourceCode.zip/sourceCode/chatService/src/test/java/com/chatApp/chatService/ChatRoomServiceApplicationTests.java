package com.chatApp.chatService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatRoomServiceApplicationTests {

	@Test
	void contextLoads() {
	}
}
