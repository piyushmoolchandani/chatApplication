package com.chatApp.chatService.repository;

import com.chatApp.chatService.model.ChatRoom;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;
/*
Source code for Submission for B.Tech Project by
 BT17CSE033 AND BT17CSE027
*/
public interface ChatRoomRepository extends MongoRepository<ChatRoom, String> {
    Optional<ChatRoom> findBySenderIdAndRecipientId(String senderId, String recipientId);
}
