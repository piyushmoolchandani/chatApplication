package com.chatApp.chatService.model;
/*
Source code for Submission for B.Tech Project by
 BT17CSE033 AND BT17CSE027
*/
public enum MessageStatus {
    RECEIVED, DELIVERED
}
