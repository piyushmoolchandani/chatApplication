package com.chatApp.chatService.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.Date;
/*
Source code for Submission for B.Tech Project by
 BT17CSE033 AND BT17CSE027
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class ChatMessage {
   @Id
   private String id;
   private String chatId;
   private String senderId;
   private String recipientId;
   private String senderName;
   private MessageStatus status;
   private String content;
   private String recipientName;
   private Date timestamp;

}
