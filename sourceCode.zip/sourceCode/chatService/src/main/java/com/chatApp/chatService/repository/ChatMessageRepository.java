package com.chatApp.chatService.repository;

import com.chatApp.chatService.model.ChatMessage;
import com.chatApp.chatService.model.MessageStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
/*
Source code for Submission for B.Tech Project by
 BT17CSE033 AND BT17CSE027
*/
public interface ChatMessageRepository
        extends MongoRepository<ChatMessage, String> {
    /*
    Source code for Submission for B.Tech Project by
     BT17CSE033 AND BT17CSE027
    */
    long countBySenderIdAndRecipientIdAndStatus(
            String senderId, String recipientId, MessageStatus status);

    List<ChatMessage> findByChatId(String chatId);
}