package com.chatApp.sessions.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.SortedMap;
import java.util.TreeMap;

/* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */

@Component
public class ConsistentHash<T> {

    @Autowired private final HashFunction hashFunction;
    int numberOfReplicas;
    private final SortedMap<Integer, T> circle = new TreeMap<Integer, T>();

    public ConsistentHash(HashFunction hashFunction,
                          Collection<T> nodes) {
        this.hashFunction = hashFunction;
        this.numberOfReplicas = 5;

        for (T node : nodes) {
            add(node);
        }
    }

    /* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */
    public void add(T node) {
        for (int i = 0; i < numberOfReplicas; i++) {
            circle.put(hashFunction.hash(node.toString() + i), node);
        }
    }

    public void remove(T node) {
        for (int i = 0; i < numberOfReplicas; i++) {
            circle.remove(hashFunction.hash(node.toString() + i));
        }
    }

    /* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */
    public T get(Object key) {
        if (circle.isEmpty()) {
            return null;
        }
        int hash = hashFunction.hash(key.toString());
        if (!circle.containsKey(hash)) {
            SortedMap<Integer, T> tailMap = circle.tailMap(hash);
            hash = tailMap.isEmpty() ? circle.firstKey() : tailMap.firstKey();
        }
        return circle.get(hash);
    }
    /* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */
}