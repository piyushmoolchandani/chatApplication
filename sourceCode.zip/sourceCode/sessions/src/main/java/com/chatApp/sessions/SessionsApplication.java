package com.chatApp.sessions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
/* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */
@SpringBootApplication
@EnableAutoConfiguration(exclude={MongoAutoConfiguration.class})
public class SessionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionsApplication.class, args);
	}
}
