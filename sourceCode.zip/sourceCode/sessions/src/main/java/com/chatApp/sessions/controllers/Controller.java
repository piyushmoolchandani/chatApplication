package com.chatApp.sessions.controllers;

import com.chatApp.sessions.util.ConsistentHash;
import com.chatApp.sessions.util.HashFunction;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
/* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */
@RestController
public class Controller {

    public ConsistentHash consistentHash;
    public HashFunction hashFunction;

    public Controller() {
        hashFunction = new HashFunction();
        List<String> list=new ArrayList<String>(){{ add("1");}};
        this.consistentHash = new ConsistentHash(this.hashFunction, list);
    }

    @GetMapping("/addNode/{Id}")
    public void addNode(@PathVariable String Id){
        consistentHash.add(Id);
    }

    @GetMapping("/removeNode/{Id}")
    public void removeNode(@PathVariable String Id){
        consistentHash.remove(Id);
    }

    @GetMapping("get/{key}")
    public Integer getHash(@PathVariable String key){
        return (Integer)consistentHash.get(key);
    }
}
