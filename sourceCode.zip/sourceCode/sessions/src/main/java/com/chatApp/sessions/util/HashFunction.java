package com.chatApp.sessions.util;

/* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */

import org.springframework.stereotype.Component;

@Component
public class HashFunction<T> {
    private final int N;

    public HashFunction() {
        N = 43;
    }

    /* -------------------------------------------------
        Source code for final year project submission by
        BT17CSE027 AND BT17CSE033
     */

    public Integer hash(String key){
        int hashVal = 7;
        int strLen = key.length();
        for (int i = 0; i < strLen; i++) {
            hashVal = hashVal*31 + key.charAt(i);
        }
        return hashVal % N;
    }
}
