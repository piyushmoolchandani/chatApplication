package com.chatApp.authorizationService.payload;


import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
@Data
@RequiredArgsConstructor
public class JwtAuthenticationResponse {

    @NonNull
    private String accessToken;
    private String tokenType = "Bearer";
}
