package com.chatApp.authorizationService.payload;

import lombok.Builder;
import lombok.Data;
/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
@Data
@Builder
public class UserSummary {

    private String id;
    private String username;
    private String name;
    private String profilePicture;
}