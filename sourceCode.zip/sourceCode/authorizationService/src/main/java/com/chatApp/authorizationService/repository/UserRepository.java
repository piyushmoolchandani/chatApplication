package com.chatApp.authorizationService.repository;

import com.chatApp.authorizationService.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;

/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
public interface UserRepository extends MongoRepository<User, String> {

    Optional<User> findByUsername(String username);
    Boolean existsByUsername(String username);
    Boolean existsByEmail(String email);
}
