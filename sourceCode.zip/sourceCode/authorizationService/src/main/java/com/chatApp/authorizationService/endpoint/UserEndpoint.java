package com.chatApp.authorizationService.endpoint;

import com.chatApp.authorizationService.exception.ResourceNotFoundException;
import com.chatApp.authorizationService.model.User;
import com.chatApp.authorizationService.model.UserDetail;
import com.chatApp.authorizationService.payload.UserSummary;
import com.chatApp.authorizationService.exception.*;
import com.chatApp.authorizationService.payload.*;
import com.chatApp.authorizationService.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
@RestController
@Slf4j
public class UserEndpoint {

    @Autowired
    private UserService userService;

    @GetMapping(value = "/users/{username}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> findUser(@PathVariable("username") String username) {
        log.info("retrieving user {}", username);

        return  userService
                .findByUsername(username)
                .map(user -> ResponseEntity.ok(user))
                .orElseThrow(() -> new ResourceNotFoundException(username));
    }

    @GetMapping(value = "/users", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> findAll() {
        log.info("retrieving all users");

        return ResponseEntity
                .ok(userService.findAll());
    }
    /* -------------------------------------------

            Source code for Submission for B.Tech Project by
             BT17CSE033 AND BT17CSE027

        ----------------------------------------------*/
    @GetMapping(value = "/users/summaries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> findAllUserSummaries(
            @AuthenticationPrincipal UserDetail userDetail) {
        log.info("retrieving all users summaries");

        return ResponseEntity.ok(userService
                .findAll()
                .stream()
                .filter(user -> !user.getUsername().equals(userDetail.getUsername()))
                .map(this::convertTo));
    }

    @GetMapping(value = "/users/me", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasRole('USER') or hasRole('FACEBOOK_USER')")
    @ResponseStatus(HttpStatus.OK)
    public UserSummary getCurrentUser(@AuthenticationPrincipal UserDetail userDetail) {
        return UserSummary
                .builder()
                .id(userDetail.getId())
                .username(userDetail.getUsername())
                .name(userDetail.getUserProfile().getDisplayName())
                .profilePicture(userDetail.getUserProfile().getProfilePictureUrl())
                .build();
    }
    /* -------------------------------------------

            Source code for Submission for B.Tech Project by
             BT17CSE033 AND BT17CSE027

        ----------------------------------------------*/
    @GetMapping(value = "/users/summary/{username}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserSummary(@PathVariable("username") String username) {
        log.info("retrieving user {}", username);

        return  userService
                .findByUsername(username)
                .map(user -> ResponseEntity.ok(convertTo(user)))
                .orElseThrow(() -> new ResourceNotFoundException(username));
    }

    private UserSummary convertTo(User user) {
        return UserSummary
                .builder()
                .id(user.getId())
                .username(user.getUsername())
                .name(user.getUserProfile().getDisplayName())
                .profilePicture(user.getUserProfile().getProfilePictureUrl())
                .build();
    }
}