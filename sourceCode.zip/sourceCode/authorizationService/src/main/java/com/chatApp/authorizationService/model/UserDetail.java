package com.chatApp.authorizationService.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.stream.Collectors;

/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
public class UserDetail extends User implements org.springframework.security.core.userdetails.UserDetails {

    public UserDetail(final User user) {
        super(user);
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        return getRoles()
                .stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" +role.getName()))
                .collect(Collectors.toSet());
    }
    /* -------------------------------------------

            Source code for Submission for B.Tech Project by
             BT17CSE033 AND BT17CSE027

        ----------------------------------------------*/
    @Override
    public boolean isAccountNonExpired() {
        return isActive();
    }

    @Override
    public boolean isAccountNonLocked() {
        return isActive();
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return isActive();
    }

    @Override
    public boolean isEnabled() {
        return isActive();
    }
}
