package com.chatApp.authorizationService.service;

import com.chatApp.authorizationService.exception.EmailAlreadyExistsException;
import com.chatApp.authorizationService.model.Role;
import com.chatApp.authorizationService.model.User;
import com.chatApp.authorizationService.repository.UserRepository;
import com.chatApp.authorizationService.exception.UsernameAlreadyExistsException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
@Service
@Slf4j
public class UserService {

    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private UserRepository userRepository;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private JwtTokenProvider tokenProvider;

    public String loginUser(String username, String password) {
       Authentication authentication = authenticationManager
               .authenticate(new UsernamePasswordAuthenticationToken(username, password));

       return tokenProvider.generateToken(authentication);
    }

    /* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
    public User registerUser(User user, Role role) {
        log.info("registering user {}", user.getUsername());

        if(userRepository.existsByUsername(user.getUsername())) {
            log.warn("username {} already exists.", user.getUsername());

            throw new UsernameAlreadyExistsException(
                    String.format("username %s already exists", user.getUsername()));
        }

        if(userRepository.existsByEmail(user.getEmail())) {
            log.warn("email {} already exists.", user.getEmail());

            throw new EmailAlreadyExistsException(
                    String.format("email %s already exists", user.getEmail()));
        }
        user.setActive(true);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRoles(new HashSet<>() {{
            add(role);
        }});

        return userRepository.save(user);
    }
    /* -------------------------------------------

            Source code for Submission for B.Tech Project by
             BT17CSE033 AND BT17CSE027

        ----------------------------------------------*/
    public List<User> findAll() {
        log.info("retrieving all users");
        return userRepository.findAll();
    }

    public Optional<User> findByUsername(String username) {
        log.info("retrieving user {}", username);
        return userRepository.findByUsername(username);
    }
    /* -------------------------------------------

            Source code for Submission for B.Tech Project by
             BT17CSE033 AND BT17CSE027

        ----------------------------------------------*/
    public Optional<User> findById(String id) {
        log.info("retrieving user {}", id);
        return userRepository.findById(id);
    }
}
