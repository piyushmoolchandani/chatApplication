package com.chatApp.authorizationService.endpoint;


import com.chatApp.authorizationService.exception.EmailAlreadyExistsException;
import com.chatApp.authorizationService.model.Profile;
import com.chatApp.authorizationService.model.Role;
import com.chatApp.authorizationService.model.User;
import com.chatApp.authorizationService.exception.BadRequestException;
import com.chatApp.authorizationService.exception.UsernameAlreadyExistsException;
import com.chatApp.authorizationService.payload.ApiResponse;
import com.chatApp.authorizationService.payload.JwtAuthenticationResponse;
import com.chatApp.authorizationService.payload.LoginRequest;
import com.chatApp.authorizationService.payload.SignUpRequest;
import com.chatApp.authorizationService.payload.*;
import com.chatApp.authorizationService.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
@RestController
@Slf4j
public class AuthEndpoint {

    @Autowired private UserService userService;

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        String token = userService.loginUser(loginRequest.getUsername(), loginRequest.getPassword());
        return ResponseEntity.ok(new JwtAuthenticationResponse(token));
    }

    @PostMapping(value = "/users", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createUser(@Valid @RequestBody SignUpRequest payload) {
        log.info("creating user {}", payload.getUsername());

        if (payload.getProfilePicUrl() == null){
            payload.setProfilePicUrl("https://i.pinimg.com/564x/b0/69/fe/b069fe5f0df53d59c56df0cdccc09214.jpg");
        }
/* -------------------------------------------

        Source code for Submission for B.Tech Project by
         BT17CSE033 AND BT17CSE027

    ----------------------------------------------*/
        User user = User
                .builder()
                .username(payload.getUsername())
                .email(payload.getEmail())
                .password(payload.getPassword())
                .userProfile(Profile
                        .builder()
                        .displayName(payload.getName())
                        .profilePictureUrl(payload.getProfilePicUrl())
                        .build())
                .build();

        try {
            userService.registerUser(user, Role.USER);
        } catch (UsernameAlreadyExistsException | EmailAlreadyExistsException e) {
            throw new BadRequestException(e.getMessage());
        }

        URI location = ServletUriComponentsBuilder
                .fromCurrentContextPath().path("/users/{username}")
                .buildAndExpand(user.getUsername()).toUri();

        return ResponseEntity
                .created(location)
                .body(new ApiResponse(true,"User registered successfully"));
    }
}